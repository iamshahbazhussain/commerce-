import Product from '../models/product.js';
import asyncHandler from 'express-async-handler';

//  Path    :   /api/product
//  Desc    :   Get all products
//  Secure  :   Public
export const getProducts = asyncHandler(async (req, res) => {
  let products = await Product.find({ category: 'Boys' });
  res.json(products);
});

//  Path    :   /api/product/:id
//  Desc    :   Get single product by id
//  Secure  :   Public
export const getProductById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const product = await Product.findById(id);
  if (product) {
    return res.json(product);
  }
  res.statusCode = 404;
  throw new Error('Product not found');
});
